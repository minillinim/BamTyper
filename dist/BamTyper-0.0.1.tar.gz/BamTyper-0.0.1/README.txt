===========
BamTyper
===========

Provides functionality so that you can work out the orientation and insert
size of a paired read data file. There's a few other bits and bobs which 
could be used to produce rough scaffolds from mapped pairs

Usage:

    #!/usr/bin/env python
    from bamtyper import properties

    ### ADD MORE!


